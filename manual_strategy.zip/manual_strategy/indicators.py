"""MC2-P1: Indicators
 			  		 			     			  	   		   	  			  	
Student Name: Hui Xia (replace with your name)
GT User ID: hxia40 (replace with your User ID)
GT ID: 903459648 (replace with your GT ID)
""" 			  		 			     			  	   		   	  			  	
 			  		 			     			  	   		   	  			  	
import pandas as pd 			  		 			     			  	   		   	  			  	
import numpy as np 			  		 			     			  	   		   	  			  	
import datetime as dt 			  		 			     			  	   		   	  			  	
import os 			  		 			     			  	   		   	  			  	
from util import get_data
import matplotlib.pyplot as plt


def author():
    return 'hxia40'  # replace tb34 with your Georgia Tech username.





def price_sma(start_date = dt.datetime(2008,1,1), end_date = dt.datetime(2009,12,31), symbols = ['JPM'], lookback = 14):
    stock_price = get_data(symbols, pd.date_range(start_date, end_date), addSPY = True, colname = 'Adj Close')
    # plot_data(stock_price)
    stock_price.fillna(method = 'ffill', inplace = True)
    stock_price.fillna(method='bfill', inplace=True)
    stock_price.drop(['SPY'], axis = 1, inplace = True)
    stock_price = stock_price/ stock_price.iloc[0, 0]

    '''Making first indicator: price/SMA'''

    sma = stock_price.copy().rolling(lookback).mean()
    p_to_sma = stock_price / sma

    # print '==========price====='
    # print stock_price
    #
    # print '========sma======'
    # print sma

    '''Making 2nd indicator: Bollinger Band Percentage'''

    stdev = stock_price.copy().rolling(lookback).std()

    upper_bb = sma + stdev * 2
    lower_bb = sma - stdev * 2

    bbp = (stock_price - upper_bb) / (upper_bb - lower_bb)

    return stock_price, sma, p_to_sma, upper_bb, lower_bb, bbp

'''Making 3rd indicator: RSI'''
def rsi(start_date = dt.datetime(2008,1,1), end_date = dt.datetime(2009,12,31), symbols = ['JPM'], lookback = 14):


    stock_price = get_data(symbols, pd.date_range(start_date, end_date), addSPY = True, colname = 'Adj Close')
    # plot_data(stock_price)
    stock_price.fillna(method='ffill', inplace=True)
    stock_price.fillna(method='bfill', inplace=True)
    stock_price.drop(['SPY'], axis=1, inplace=True)
    daily_return = stock_price - stock_price.shift(1)
    print '=====daily_return=====\n', daily_return
    up_gain = daily_return.copy()
    for i in range(daily_return.shape[0]):


        # print daily_return.iloc[i, 0]
        # if i > lookback:

        up_gain.iloc[i, 0] = daily_return.iloc[i-lookback+1: i+1, 0].where(daily_return > 0).sum()

    print up_gain
    print len(up_gain)



#
# '''Making 4th indicator: MFI'''
# def MFI(start_date = dt.datetime(2008,1,1), end_date = dt.datetime(2009,12,31), symbols = ['JPM']):
#     stock_price = get_data(symbols, pd.date_range(start_date, end_date), addSPY = True, colname = 'Volume')
#     # plot_data(stock_price)
#     stock_price.fillna(method = 'ffill', inplace = True)
#     stock_price.fillna(method='bfill', inplace=True)
#     print stock_price

'''Making 5th indicator: vix'''
def vix(start_date = dt.datetime(2008,1,1), end_date = dt.datetime(2009,12,31), symbols = ['$VIX']):
    stock_price = get_data(symbols, pd.date_range(start_date, end_date), addSPY = True, colname = 'Adj Close')
    # plot_data(stock_price)
    stock_price.fillna(method = 'ffill', inplace = True)
    stock_price.fillna(method='bfill', inplace=True)
    stock_price.drop(['SPY'], axis=1, inplace=True)


    return stock_price
#
#
# def test_code():
#     pass


if __name__ == "__main__":

    # stock_price, sma, p_to_sma, upper_bb, lower_bb, bbp = price_sma()
    # '''plotting Indicator 1: Price / SMA'''
    # plt.plot(stock_price.index, stock_price,  label='Price')
    # plt.plot(stock_price.index, sma, label='SMA')
    # plt.plot(stock_price.index, p_to_sma, label='Price/SMA')
    # plt.ylabel('Value')
    # plt.xlabel('Date')
    # plt.title('Indicator 1: Price / SMA')
    # plt.legend(loc='best')
    # plt.show()
    # plt.gcf().clear()
    #
    # '''plotting Indicator 2: Bollinger Band %'''
    # plt.plot(stock_price.index, stock_price, label='Price')
    #
    # plt.plot(stock_price.index, upper_bb, label='Top Bollinger Band')
    # plt.plot(stock_price.index, lower_bb, label='Bottom Bollinger Band')
    # plt.ylabel('Value')
    # plt.xlabel('Date')
    # plt.title('Indicator 2: Bollinger Band Percentage - a')
    # plt.legend(loc='best')
    # plt.show()
    # plt.gcf().clear()
    #
    #
    # plt.plot(stock_price.index, bbp, label='Bollinger Band Percentage')
    #
    # plt.ylabel('Value')
    # plt.xlabel('Date')
    # plt.title('Indicator 2: Bollinger Band Percentage - b')
    # plt.legend(loc='best')
    # plt.show()
    # plt.gcf().clear()
    #
    #
    #
    #
    #
    # '''plotting Indicator 5: VIX'''
    # vix_values = vix()
    #
    # plt.plot(stock_price.index, vix_values, label='VIX')
    #
    # plt.ylabel('Value')
    # plt.xlabel('Date')
    # plt.title('Indicator 5: VIX')
    # plt.legend()
    # plt.show()
    # plt.gcf().clear()






    # bollinger_percentage()
    rsi()
    # MFI()
    # vix()